import React from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowLeft,
  Brain,
  Layers3,
  Network,
  Rocket,
  Scale,
  Sigma,
  Workflow,
} from 'lucide-react';

const architectureFamilies = [
  {
    name: 'Transformer',
    badge: '主流基础设施',
    summary: '靠自注意力一次性建立全局上下文，是大模型时代的默认骨架。',
    strengths: ['长上下文建模强', '易于并行训练', '生态最成熟'],
    tradeoffs: ['推理显存开销高', '长序列成本随上下文上升明显', '需要配套 KV Cache 与并行策略'],
    fit: '通用大语言模型、多模态主干、代码模型、长文档理解',
    detail:
      '核心价值不是“更聪明”，而是更擅长在任意两个 token 之间直接建立关系。训练端容易大规模并行，推理端则需要围绕 KV Cache、量化、Paged Attention 和批处理做大量工程优化。',
  },
  {
    name: 'CNN',
    badge: '局部归纳偏置',
    summary: '用卷积核提取局部结构，参数共享强，擅长空间模式识别。',
    strengths: ['图像特征提取稳定', '参数利用率高', '在边缘设备上部署成熟'],
    tradeoffs: ['长距离依赖不如注意力直接', '任务迁移灵活性有限'],
    fit: '图像分类、检测、分割、工业视觉、轻量端侧推理',
    detail:
      'CNN 的价值在于把“局部平移不变性”写进模型先验里。对规则明确、数据分布稳定的视觉任务，它往往仍然比“大一统模型”更便宜、更稳、更易解释。',
  },
  {
    name: 'RNN / LSTM',
    badge: '时序递归建模',
    summary: '按时间步逐步更新隐藏状态，天然适合流式处理和低延迟时序任务。',
    strengths: ['流式输入自然', '状态量小', '在资源受限场景仍有价值'],
    tradeoffs: ['并行度低', '长依赖容易衰减', '训练效率不如 Transformer'],
    fit: '语音片段流处理、传感器时序、传统预测系统',
    detail:
      '它不是“过时模型”，而是更适合那些输入天然逐帧到来、上下文窗口不大、延迟预算极紧的场景。若系统重视稳定的在线状态更新，RNN 仍然可用。',
  },
  {
    name: 'State Space / Mamba',
    badge: '长序列新路线',
    summary: '尝试以更线性的方式处理长序列，目标是兼顾长上下文与更优吞吐。',
    strengths: ['长序列推理潜力大', '理论上更省内存', '适合序列扫描'],
    tradeoffs: ['生态仍在成熟', '工具链不如 Transformer 完整', '任务泛化还要看具体实现'],
    fit: '超长日志、DNA 序列、流式信号、超长上下文研究探索',
    detail:
      '这一类架构最值得关注的不是概念新，而是它在工程账本上的可能优势。如果你的瓶颈是长序列成本而不是通用生态，State Space 模型值得继续跟进。',
  },
  {
    name: 'Diffusion / MoE',
    badge: '专用能力增强',
    summary: '前者擅长生成连续信号，后者擅长在固定算力内扩张参数容量。',
    strengths: ['Diffusion 图像视频质量强', 'MoE 可扩大模型容量', '便于按任务分工'],
    tradeoffs: ['Diffusion 采样慢', 'MoE 路由与负载均衡复杂', '训练与服务链路更重'],
    fit: '文生图、视频生成、大规模专家模型、任务分工明显的系统',
    detail:
      '这两类不应混成“更高级模型”。Diffusion 解决的是连续生成质量，MoE 解决的是参数容量与计算预算的矛盾。它们都更像策略组件，而不是默认底座。',
  },
];

const lifecycleLayers = [
  {
    phase: '训练层',
    title: 'PyTorch / TensorFlow / JAX',
    description:
      '这是定义模型、执行训练、分布式并行和自动微分的底层训练框架。它们决定你的研发习惯、调试方式和大规模训练路径。',
  },
  {
    phase: '模型生态层',
    title: 'Transformers / timm / Diffusers / Lightning',
    description:
      '这是复用现成模型、Trainer、权重格式和微调套路的中间层。大多数团队不是从零造轮子，而是靠这一层提速。',
  },
  {
    phase: '推理服务层',
    title: 'vLLM / TensorRT-LLM / ONNX Runtime / TGI',
    description:
      '这层只关心“如何更快、更省显存、更稳地把模型跑起来”。训练框架选型正确，不代表线上吞吐就高。',
  },
  {
    phase: '应用编排层',
    title: 'LangGraph / DSPy / LlamaIndex / 自研工作流',
    description:
      '这层负责多步调用、工具接入、记忆、路由和评估闭环。它不是模型框架，而是把模型变成产品能力的流程层。',
  },
];

const frameworkTable = [
  {
    name: 'PyTorch',
    role: '研究到产品的默认训练框架',
    strengths: '动态图直接，社区最大，调试成本最低，Hugging Face 生态配合最好',
    caution: '超大规模训练通常还要叠加 DeepSpeed、FSDP、Megatron 等组件',
    bestFor: '大多数创业团队、应用团队、模型迭代快的研发组织',
  },
  {
    name: 'TensorFlow / Keras',
    role: '成熟工业栈与部分历史系统',
    strengths: '部署工具链广，历史存量大，部分企业内流程仍围绕它搭建',
    caution: '前沿大模型生态明显弱于 PyTorch',
    bestFor: '已有 TensorFlow 资产、移动端和既有生产系统迁移成本高的团队',
  },
  {
    name: 'JAX / Flax',
    role: '高性能数值计算与大规模训练研究',
    strengths: 'XLA 编译、函数式风格、在 TPU 和部分大规模研究训练中表现突出',
    caution: '上手门槛高，团队协作和招聘面相对窄',
    bestFor: '研究型团队、追求极限训练效率、具备较强基础设施能力的组织',
  },
  {
    name: 'vLLM',
    role: 'LLM 推理服务引擎',
    strengths: 'Paged Attention、批量吞吐高、OpenAI 兼容服务能力成熟',
    caution: '它不负责训练，也不替你解决业务链路设计',
    bestFor: '要把大语言模型稳定变成线上接口的产品团队',
  },
];

const decisionChecklist = [
  {
    title: '先问任务结构',
    body:
      '输入是文本、图像、视频还是时序信号？是单轮分类，还是长链路生成？如果任务结构都没定清，谈“最先进架构”只会空转。',
  },
  {
    title: '再问工程账本',
    body:
      '训练预算、推理显存、响应时延、并发规模要一起算。很多方案论文里更强，但一上线就被显存和吞吐打回去。',
  },
  {
    title: '最后问组织能力',
    body:
      '团队熟悉 PyTorch 还是 TensorFlow？有没有服务化经验、评估体系和 GPU 调度能力？架构选择本质上也是组织选择。',
  },
];

const deliverySteps = [
  {
    label: '1. 模型主干',
    text: '确定是 Transformer、视觉骨干、扩散模型还是其他结构，先决定“信息如何在模型内部流动”。',
  },
  {
    label: '2. 训练框架',
    text: '确定用 PyTorch、TensorFlow 或 JAX 管训练、微调、实验和分布式作业。',
  },
  {
    label: '3. 推理引擎',
    text: '为线上吞吐和时延选择 vLLM、TensorRT-LLM、ONNX Runtime 等，不要把训练工具错当服务层。',
  },
  {
    label: '4. 产品流程',
    text: '再决定是否需要 Agent 工作流、RAG、记忆、评估与反馈闭环，把模型真正接进网站功能。',
  },
];

const architectureFlow = [
  {
    title: '输入表示',
    body: '文本会先被切成 token，图像会被切成 patch，语音会变成声学特征。模型并不直接理解“句子”或“图片”，而是先接收统一的数值表示。'
  },
  {
    title: '上下文混合',
    body: 'Transformer 用注意力做全局混合，CNN 用局部卷积做空间提取，State Space 则尝试用更线性的状态更新去保留长依赖。'
  },
  {
    title: '中间表征',
    body: '经过多层堆叠后，模型会形成更高层的语义表征。这个阶段决定它能否把局部模式变成跨句、跨模态、跨时间的理解。'
  },
  {
    title: '任务头输出',
    body: '最后根据任务接分类头、生成头、检测头或策略头。很多“模型能力差异”其实不是底座不同，而是最后输出结构和训练目标不同。'
  }
];

const systemDiagram = [
  {
    title: '模型架构',
    subtitle: 'Transformer / CNN / State Space / Diffusion',
    tone: 'from-sky-50 to-white'
  },
  {
    title: '训练框架',
    subtitle: 'PyTorch / TensorFlow / JAX',
    tone: 'from-emerald-50 to-white'
  },
  {
    title: '推理服务',
    subtitle: 'vLLM / TensorRT-LLM / ONNX Runtime',
    tone: 'from-amber-50 to-white'
  },
  {
    title: '产品编排',
    subtitle: 'RAG / Agent Workflow / Memory / Evaluation',
    tone: 'from-violet-50 to-white'
  }
];

const foldableTerms = [
  {
    term: 'Attention / 自注意力',
    explain: '让每个 token 在计算时都能查看其他 token 的信息，因此模型可以直接建立远距离依赖。这是 Transformer 能处理长文本和复杂关系的关键。',
    why: '如果你页面里提 Transformer，却不解释 attention，读者很难理解它为什么替代了很多传统序列模型。'
  },
  {
    term: 'KV Cache',
    explain: '在推理时缓存历史 token 的 key/value，避免每次生成新 token 都把前文完整重算。',
    why: '它直接决定 LLM 在线服务的延迟和显存账本，是“训练会了”到“线上跑得动”之间最重要的工程桥梁之一。'
  },
  {
    term: 'Context Window / 上下文窗口',
    explain: '模型一次最多能读取和利用的上下文长度。窗口越大，不代表一定越聪明，只代表它有机会参考更多历史信息。',
    why: '很多公开页面把长上下文写成绝对优势，但真正的成本会落在显存、吞吐和注意力复杂度上。'
  },
  {
    term: 'MoE / Mixture of Experts',
    explain: '让不同输入只激活部分专家网络，用更少的实时计算换取更大的总参数规模。',
    why: '它解释了为什么一些模型参数量极大，但单次推理的实际激活成本并没有等比例上升。'
  },
  {
    term: 'Quantization / 量化',
    explain: '把模型权重从更高精度压缩到更低精度表示，比如从 FP16 到 INT8 / INT4，以换取更低显存占用和更高吞吐。',
    why: '公开网站如果面向工程读者，量化是必须提的，因为很多产品能不能上线，靠的不是训练，而是量化后能否装进预算内的卡。'
  },
  {
    term: 'Fine-tuning / 微调',
    explain: '在基础模型上继续训练，让它适应特定数据、任务或风格。它和 RAG 不同，前者修改参数，后者主要补上下文。',
    why: '很多读者会把“给模型更多资料”和“改模型本身”混为一谈，这里需要明确拆开。'
  }
];

const ArchitectureGuidePage = () => {
  return (
    <div className="mx-auto max-w-7xl pb-16">
      <section className="overflow-hidden rounded-[34px] border border-slate-200 bg-[radial-gradient(circle_at_top_right,_rgba(56,189,248,0.14),_transparent_22%),linear-gradient(135deg,_#09111f_0%,_#11263e_46%,_#10404f_100%)] px-6 py-8 text-white shadow-[0_28px_90px_rgba(15,23,42,0.18)] sm:px-8 lg:px-10 lg:py-10">
        <div className="grid gap-8 lg:grid-cols-[minmax(0,1.15fr)_340px]">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.32em] text-slate-200">
              Architecture Field Manual
            </div>
            <h1 className="mt-5 max-w-4xl text-4xl font-semibold tracking-[-0.05em] text-white sm:text-5xl lg:text-7xl">
              AI模型架构与算法框架详解
            </h1>
            <p className="mt-5 max-w-3xl text-base leading-8 text-slate-200 sm:text-lg">
              这页不是“术语拼盘”，而是一份给公开网站读者看的判断手册。它把模型内部结构、训练框架、推理引擎和应用编排拆开讲，
              让读者知道为什么选某条路线，而不是只看到一堆看似高级的名字。
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/glossary"
                className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-5 py-3 text-sm font-semibold text-white transition hover:bg-white hover:text-slate-950"
              >
                <ArrowLeft className="h-4 w-4" />
                返回 AI 知识库
              </Link>
              <a
                href="#framework-stack"
                className="inline-flex items-center gap-2 rounded-full border border-sky-300/30 bg-sky-300/10 px-5 py-3 text-sm font-semibold text-sky-100 transition hover:bg-sky-300/20"
              >
                <Workflow className="h-4 w-4" />
                直接看工程框架选择
              </a>
            </div>
          </div>

          <div className="grid gap-4">
            <div className="rounded-[26px] border border-white/12 bg-white/10 p-5 backdrop-blur">
              <div className="text-xs uppercase tracking-[0.28em] text-sky-100/80">核心目标</div>
              <div className="mt-3 text-2xl font-semibold">把“模型”和“框架”分清楚</div>
              <p className="mt-2 text-sm leading-7 text-slate-200">
                模型架构回答“信息怎么流”，框架回答“模型怎么训、怎么跑、怎么接进产品”。这两个层次混在一起，是很多 AI 页面看起来很空泛的根源。
              </p>
            </div>
            <div className="rounded-[26px] border border-white/12 bg-white/10 p-5 backdrop-blur">
              <div className="text-xs uppercase tracking-[0.28em] text-amber-100/80">适合谁看</div>
              <p className="mt-3 text-sm leading-7 text-slate-200">
                产品经理用它建立判断标准，工程师用它拆训练与服务栈，研究者用它快速对齐一页面向公众的解释口径。
              </p>
            </div>
            <div className="rounded-[26px] border border-white/12 bg-white/10 p-5 backdrop-blur">
              <div className="text-xs uppercase tracking-[0.28em] text-emerald-100/80">页面结构</div>
              <p className="mt-3 text-sm leading-7 text-slate-200">
                先看架构家族，再看框架栈，最后给出上线时真正要用的决策顺序，不再停留在“这个也很重要”的空话。
              </p>
            </div>
          </div>
        </div>
      </section>

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-6">
          <section className="rounded-[30px] border border-slate-200 bg-white p-6 shadow-[0_16px_60px_rgba(15,23,42,0.07)] sm:p-8">
            <div className="flex items-center gap-3 text-sm font-semibold uppercase tracking-[0.24em] text-amber-700">
              <Network className="h-4 w-4" />
              图示结构图
            </div>
            <h2 className="mt-4 text-3xl font-semibold tracking-[-0.04em] text-slate-950 sm:text-4xl">
              用一张信息流图，把模型内部过程真正讲清楚
            </h2>
            <p className="mt-4 max-w-4xl text-base leading-8 text-slate-600">
              下面这张图不是数学公式，而是给公开网站读者看的结构图。它说明模型从输入到输出到底经过了哪些阶段，也解释了为什么“同样叫 AI 模型”，不同架构的强项完全不同。
            </p>

            <div className="mt-8 grid gap-4 lg:grid-cols-4">
              {architectureFlow.map((step, index) => (
                <div key={step.title} className="relative rounded-[24px] border border-slate-200 bg-[linear-gradient(180deg,_#ffffff_0%,_#f8fafc_100%)] p-5">
                  <div className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
                    Step {index + 1}
                  </div>
                  <h3 className="mt-3 text-xl font-semibold text-slate-950">{step.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-600">{step.body}</p>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-[30px] border border-slate-200 bg-white p-6 shadow-[0_16px_60px_rgba(15,23,42,0.07)] sm:p-8">
            <div className="flex items-center gap-3 text-sm font-semibold uppercase tracking-[0.24em] text-sky-700">
              <Brain className="h-4 w-4" />
              架构判断图
            </div>
            <h2 className="mt-4 text-3xl font-semibold tracking-[-0.04em] text-slate-950 sm:text-4xl">
              先看模型如何处理信息，再谈它是否“先进”
            </h2>
            <p className="mt-4 max-w-4xl text-base leading-8 text-slate-600">
              一个模型架构最核心的问题只有三个：它如何接收上下文、如何保留状态、如何在计算预算内提取关键信息。
              真正的选择往往不是“哪个好”，而是你的任务更需要全局依赖、局部归纳偏置、长序列吞吐，还是生成质量。
            </p>

            <div className="mt-8 grid gap-4 xl:grid-cols-2">
              {architectureFamilies.map((family) => (
                <article
                  key={family.name}
                  className="rounded-[26px] border border-slate-200 bg-[linear-gradient(180deg,_#ffffff_0%,_#f8fafc_100%)] p-6"
                >
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <h3 className="text-2xl font-semibold tracking-[-0.03em] text-slate-950">
                      {family.name}
                    </h3>
                    <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-slate-600">
                      {family.badge}
                    </span>
                  </div>
                  <p className="mt-3 text-base leading-7 text-slate-700">{family.summary}</p>
                  <p className="mt-4 text-sm leading-7 text-slate-600">{family.detail}</p>

                  <div className="mt-5 grid gap-4 sm:grid-cols-2">
                    <div>
                      <div className="text-xs font-semibold uppercase tracking-[0.24em] text-emerald-700">
                        优势
                      </div>
                      <ul className="mt-3 space-y-2 text-sm leading-7 text-slate-600">
                        {family.strengths.map((item) => (
                          <li key={item}>• {item}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <div className="text-xs font-semibold uppercase tracking-[0.24em] text-amber-700">
                        代价
                      </div>
                      <ul className="mt-3 space-y-2 text-sm leading-7 text-slate-600">
                        {family.tradeoffs.map((item) => (
                          <li key={item}>• {item}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="mt-5 rounded-[22px] border border-slate-200 bg-white px-4 py-4 text-sm leading-7 text-slate-600">
                    <span className="font-semibold text-slate-950">典型适配场景：</span>
                    {family.fit}
                  </div>
                </article>
              ))}
            </div>
          </section>

          <section
            id="framework-stack"
            className="rounded-[30px] border border-slate-200 bg-white p-6 shadow-[0_16px_60px_rgba(15,23,42,0.07)] sm:p-8"
          >
            <div className="flex items-center gap-3 text-sm font-semibold uppercase tracking-[0.24em] text-emerald-700">
              <Layers3 className="h-4 w-4" />
              工程栈拆解
            </div>
            <h2 className="mt-4 text-3xl font-semibold tracking-[-0.04em] text-slate-950 sm:text-4xl">
              框架不止一层，训练、推理、编排必须拆开理解
            </h2>
            <p className="mt-4 max-w-4xl text-base leading-8 text-slate-600">
              很多网站把 PyTorch、Transformers、vLLM、LangChain 都写成“AI 框架”，结果读者根本分不清谁负责训练，谁负责推理，谁负责业务流程。
              正确的解释方式应该按生命周期展开。
            </p>

            <div className="mt-8 space-y-4">
              {lifecycleLayers.map((item) => (
                <div
                  key={item.phase}
                  className="grid gap-4 rounded-[24px] border border-slate-200 bg-[linear-gradient(180deg,_#fff_0%,_#f8fafc_100%)] p-5 md:grid-cols-[120px_minmax(0,1fr)]"
                >
                  <div className="text-xs font-semibold uppercase tracking-[0.24em] text-sky-700">
                    {item.phase}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-slate-950">{item.title}</h3>
                    <p className="mt-2 text-sm leading-7 text-slate-600">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 overflow-hidden rounded-[24px] border border-slate-200">
              <table className="min-w-full border-collapse bg-white text-left">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-4 py-4 text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
                      框架
                    </th>
                    <th className="px-4 py-4 text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
                      角色
                    </th>
                    <th className="px-4 py-4 text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
                      优势
                    </th>
                    <th className="px-4 py-4 text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
                      注意点
                    </th>
                    <th className="px-4 py-4 text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
                      适合谁
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {frameworkTable.map((row) => (
                    <tr key={row.name} className="border-t border-slate-200 align-top">
                      <td className="px-4 py-4 text-sm font-semibold text-slate-950">{row.name}</td>
                      <td className="px-4 py-4 text-sm leading-7 text-slate-600">{row.role}</td>
                      <td className="px-4 py-4 text-sm leading-7 text-slate-600">{row.strengths}</td>
                      <td className="px-4 py-4 text-sm leading-7 text-slate-600">{row.caution}</td>
                      <td className="px-4 py-4 text-sm leading-7 text-slate-600">{row.bestFor}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-8 rounded-[26px] border border-slate-200 bg-[#f6f2e8] p-5">
              <div className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
                一张站点级技术栈图
              </div>
              <div className="mt-4 grid gap-4 lg:grid-cols-4">
                {systemDiagram.map((item, index) => (
                  <div
                    key={item.title}
                    className={`rounded-[22px] border border-slate-200 bg-gradient-to-b ${item.tone} p-5`}
                  >
                    <div className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
                      Layer {index + 1}
                    </div>
                    <h3 className="mt-3 text-lg font-semibold text-slate-950">{item.title}</h3>
                    <p className="mt-2 text-sm leading-7 text-slate-600">{item.subtitle}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="rounded-[30px] border border-slate-200 bg-white p-6 shadow-[0_16px_60px_rgba(15,23,42,0.07)] sm:p-8">
            <div className="flex items-center gap-3 text-sm font-semibold uppercase tracking-[0.24em] text-violet-700">
              <Rocket className="h-4 w-4" />
              上线决策顺序
            </div>
            <h2 className="mt-4 text-3xl font-semibold tracking-[-0.04em] text-slate-950 sm:text-4xl">
              真正做公开站点时，应该按这四步做选择
            </h2>
            <div className="mt-8 grid gap-4 lg:grid-cols-2">
              {deliverySteps.map((step) => (
                <div
                  key={step.label}
                  className="rounded-[24px] border border-slate-200 bg-[linear-gradient(180deg,_#ffffff_0%,_#f8fafc_100%)] p-5"
                >
                  <div className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
                    {step.label}
                  </div>
                  <p className="mt-3 text-base leading-8 text-slate-700">{step.text}</p>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-[30px] border border-slate-200 bg-white p-6 shadow-[0_16px_60px_rgba(15,23,42,0.07)] sm:p-8">
            <div className="flex items-center gap-3 text-sm font-semibold uppercase tracking-[0.24em] text-slate-700">
              <Layers3 className="h-4 w-4" />
              折叠术语解释
            </div>
            <h2 className="mt-4 text-3xl font-semibold tracking-[-0.04em] text-slate-950 sm:text-4xl">
              读者真正会卡住的术语，应该能展开看详细解释
            </h2>
            <p className="mt-4 max-w-4xl text-base leading-8 text-slate-600">
              公开网站不适合把所有解释一次性摊平。更好的方式是把高频术语做成可折叠结构，让第一次阅读的人先过主线，想深入时再展开细节。
            </p>

            <div className="mt-8 space-y-3">
              {foldableTerms.map((item) => (
                <details
                  key={item.term}
                  className="group rounded-[22px] border border-slate-200 bg-[linear-gradient(180deg,_#ffffff_0%,_#f8fafc_100%)] p-5"
                >
                  <summary className="cursor-pointer list-none text-lg font-semibold text-slate-950 marker:hidden">
                    <div className="flex items-center justify-between gap-4">
                      <span>{item.term}</span>
                      <span className="text-xs uppercase tracking-[0.24em] text-slate-400 transition group-open:text-slate-700">
                        展开说明
                      </span>
                    </div>
                  </summary>
                  <div className="mt-4 space-y-3 text-sm leading-8 text-slate-600">
                    <p>{item.explain}</p>
                    <p>
                      <span className="font-semibold text-slate-950">为什么这项术语值得单独解释：</span>
                      {item.why}
                    </p>
                  </div>
                </details>
              ))}
            </div>
          </section>
        </div>

        <aside className="space-y-6">
          <section className="rounded-[28px] border border-slate-200 bg-[#f6f2e8] p-6 shadow-[0_14px_40px_rgba(15,23,42,0.06)]">
            <div className="flex items-center gap-3 text-sm font-semibold uppercase tracking-[0.24em] text-slate-700">
              <Scale className="h-4 w-4" />
              三条判断线
            </div>
            <div className="mt-5 space-y-4">
              {decisionChecklist.map((item) => (
                <div key={item.title} className="rounded-[22px] border border-slate-200 bg-white px-4 py-4">
                  <h3 className="text-base font-semibold text-slate-950">{item.title}</h3>
                  <p className="mt-2 text-sm leading-7 text-slate-600">{item.body}</p>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_14px_40px_rgba(15,23,42,0.06)]">
            <div className="flex items-center gap-3 text-sm font-semibold uppercase tracking-[0.24em] text-slate-700">
              <Sigma className="h-4 w-4" />
              页面要传达的边界
            </div>
            <ul className="mt-5 space-y-3 text-sm leading-7 text-slate-600">
              <li>• Transformer 是架构，不是训练框架。</li>
              <li>• PyTorch 是训练框架，不是线上吞吐优化器。</li>
              <li>• vLLM 是推理引擎，不负责你的业务流程设计。</li>
              <li>• LangGraph 这类工具是编排层，不是模型本身。</li>
            </ul>
          </section>

          <section className="rounded-[28px] border border-slate-200 bg-[linear-gradient(180deg,_#09111f_0%,_#13253d_100%)] p-6 text-white shadow-[0_14px_40px_rgba(15,23,42,0.12)]">
            <div className="flex items-center gap-3 text-sm font-semibold uppercase tracking-[0.24em] text-sky-100">
              <Network className="h-4 w-4" />
              写给公开网站的建议
            </div>
            <p className="mt-4 text-sm leading-8 text-slate-200">
              公众页面最怕两件事：第一，所有概念都只写一句漂亮话；第二，把训练、推理、应用编排混成一层。你这页现在已经改成“能让人做判断”的结构，而不是“看上去像 AI 页面”的结构。
            </p>
          </section>
        </aside>
      </div>
    </div>
  );
};

export default ArchitectureGuidePage;
