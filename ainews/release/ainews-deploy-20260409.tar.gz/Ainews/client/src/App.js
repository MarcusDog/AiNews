import React, { useState, useCallback } from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import './index.css';

// 导入上下文
import { SocketProvider } from './contexts/SocketContext';
import { AuthProvider } from './contexts/AuthContext';
import { UserDataProvider } from './contexts/UserDataContext';

// 导入组件
import Header from './components/Header';
import NewsList from './components/NewsList';
import NewsDetail from './components/NewsDetail';
import Analytics from './pages/Analytics';
import SearchPage from './pages/SearchPage';
import SettingsPage from './pages/SettingsPage';
import GlossaryPage from './pages/GlossaryPage';
import ArchitectureGuidePage from './pages/ArchitectureGuidePage';
import HealthPage from './pages/HealthPage';
import FavoritesPage from './pages/FavoritesPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import AccountPage from './pages/AccountPage';
import ProtectedRoute from './components/ProtectedRoute';
import SystemStatus from './components/SystemStatus';

function AppContent() {
  const [selectedCategory, setSelectedCategory] = useState('全部');
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const location = useLocation();

  const handleRefresh = useCallback(() => {
    setRefreshTrigger(prev => prev + 1);
  }, []);

  const isAuthPage = location.pathname === '/login' || location.pathname === '/register';

  return (
    <div className={`min-h-screen ${isAuthPage ? 'bg-[#f7f6f3]' : 'bg-gray-50'}`}>
      {!isAuthPage ? (
        <Header
          onRefresh={handleRefresh}
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
        />
      ) : null}

      <main className={isAuthPage ? 'min-w-0' : 'pt-28 lg:pt-16 min-w-0'}>
        <div className={isAuthPage ? 'w-full' : 'w-full px-4 sm:px-6 lg:px-8 py-6'}>
          <div className="w-full">
            <Routes>
              <Route
                path="/"
                element={
                  <NewsList
                    category={selectedCategory}
                    refreshTrigger={refreshTrigger}
                  />
                }
              />
              <Route path="/news/:id" element={<NewsDetail />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/settings" element={<SettingsPage />} />
              <Route path="/glossary" element={<GlossaryPage />} />
              <Route path="/glossary/architecture-guide" element={<ArchitectureGuidePage />} />
              <Route path="/health" element={<HealthPage />} />
              <Route path="/favorites" element={<FavoritesPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route
                path="/account"
                element={(
                  <ProtectedRoute>
                    <AccountPage />
                  </ProtectedRoute>
                )}
              />
            </Routes>
          </div>
        </div>
      </main>

      {!isAuthPage ? <SystemStatus onRefresh={handleRefresh} /> : null}
    </div>
  );
}

function App() {
  return (
    <SocketProvider>
      <AuthProvider>
        <UserDataProvider>
          <Router>
            <AppContent />
          </Router>
        </UserDataProvider>
      </AuthProvider>
    </SocketProvider>
  );
}

export default App;
