import React from 'react';
import { ArrowLeft, Brain } from 'lucide-react';
import { Link } from 'react-router-dom';

const AuthShell = ({ eyebrow, title, subtitle, alternateAction, children }) => {
  return (
    <div className="relative min-h-screen overflow-hidden bg-[#f7f6f3] fade-in">
      <div className="auth-grid absolute inset-0 opacity-60" />
      <div className="relative mx-auto flex min-h-screen max-w-[1600px] flex-col px-4 py-4 sm:px-6 lg:px-8">
        <div className="mb-6 flex items-center justify-between rounded-[24px] border border-white/60 bg-white/80 px-4 py-3 shadow-lg shadow-slate-200/60 backdrop-blur-sm">
          <Link to="/" className="inline-flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-950 text-white shadow-lg shadow-slate-900/20">
              <Brain className="h-5 w-5" />
            </span>
            <span>
              <span className="block text-lg font-semibold text-slate-900">AI资讯平台</span>
              <span className="block text-sm text-slate-500">账号入口与用户体系</span>
            </span>
          </Link>

          <Link
            to="/"
            className="inline-flex items-center rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:border-slate-300 hover:bg-slate-50"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            返回首页
          </Link>
        </div>

        <div className="grid flex-1 gap-6 lg:grid-cols-[0.92fr_1.08fr]">
          <section className="relative overflow-hidden rounded-[36px] border border-slate-200 bg-[radial-gradient(circle_at_top_right,_rgba(34,197,94,0.12),_transparent_18%),radial-gradient(circle_at_bottom_left,_rgba(250,204,21,0.15),_transparent_18%),linear-gradient(135deg,_#020617_0%,_#0f172a_48%,_#0f3b63_100%)] px-6 py-7 text-white shadow-2xl shadow-slate-900/10 sm:px-8 lg:px-10 lg:py-10">
            <div className="relative flex h-full flex-col justify-between gap-12">
              <div className="space-y-5">
                <div className="inline-flex items-center rounded-full border border-white/12 bg-white/10 px-3 py-1 text-xs font-medium uppercase tracking-[0.24em] text-sky-100">
                  {eyebrow}
                </div>
                <h1 className="max-w-xl text-4xl font-semibold leading-[1.02] text-white sm:text-5xl lg:text-6xl">
                  {title}
                </h1>
                {subtitle ? (
                  <p className="max-w-lg text-sm leading-7 text-slate-300 sm:text-base">
                    {subtitle}
                  </p>
                ) : null}
              </div>

              <div className="grid gap-3 rounded-[28px] border border-white/12 bg-white/[0.06] p-5 backdrop-blur-sm">
                <div className="rounded-2xl border border-white/10 bg-white/[0.05] px-4 py-4">
                  <div className="text-xs uppercase tracking-[0.18em] text-sky-100/70">入口</div>
                  <div className="mt-2 text-lg font-semibold">邮箱登录 / 注册</div>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.05] px-4 py-4">
                  <div className="text-xs uppercase tracking-[0.18em] text-sky-100/70">说明</div>
                  <div className="mt-2 text-sm text-slate-300">填写账号信息后即可继续。</div>
                </div>
              </div>
            </div>
          </section>

          <section className="rounded-[36px] border border-white/70 bg-white/90 p-6 shadow-2xl shadow-slate-200/70 backdrop-blur sm:p-8 lg:p-10">
            <div className="mb-8 flex items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="text-sm font-medium text-slate-900">账号入口</div>
                <p className="text-sm text-slate-500">完成后自动进入站内账户页</p>
              </div>
              {alternateAction}
            </div>
            {children}
          </section>
        </div>
      </div>
    </div>
  );
};

export default AuthShell;
