const newsSchedules = {
  dailyMorning: '0 8 * * *',
  recurring: '0 */3 * * *',
  cleanup: '0 2 * * *'
};

module.exports = {
  newsSchedules
};
