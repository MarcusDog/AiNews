const test = require('node:test');
const assert = require('node:assert/strict');

const schedules = require('../config/schedules');

test('news update schedule keeps 8am full refresh and 3-hour interval updates', () => {
  assert.equal(schedules.newsSchedules.dailyMorning, '0 8 * * *');
  assert.equal(schedules.newsSchedules.recurring, '0 */3 * * *');
});
