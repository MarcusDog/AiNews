const test = require('node:test');
const assert = require('node:assert/strict');

const NewsServiceModule = require('../services/NewsService');
const { NewsService } = NewsServiceModule;

test('getActiveRssSources excludes disabled feeds from update scheduling', () => {
  const service = new NewsService();

  const activeSources = service.getActiveRssSources();

  assert(activeSources.length > 0);
  assert(activeSources.every((source) => source.enabled !== false));
  assert(activeSources.some((source) => source.name === 'OpenAI Blog'));
  assert(!activeSources.some((source) => source.name === 'DeepMind Blog'));
});

test('validateFeedHttpResponse rejects upstream 404 responses', () => {
  const service = new NewsService();

  assert.throws(
    () =>
      service.validateFeedHttpResponse({
        status: 404,
        data: '<html><body>not found</body></html>',
        headers: { 'content-type': 'text/html; charset=utf-8' }
      }),
    /HTTP 404/
  );
});

test('validateFeedHttpResponse rejects html pages that are not feeds', () => {
  const service = new NewsService();

  assert.throws(
    () =>
      service.validateFeedHttpResponse({
        status: 200,
        data: '<!DOCTYPE html><html><head><title>Landing page</title></head><body>Hello</body></html>',
        headers: { 'content-type': 'text/html; charset=utf-8' }
      }),
    /不是有效的RSS或Atom feed/
  );
});

test('validateFeedHttpResponse accepts xml feeds', () => {
  const service = new NewsService();

  assert.doesNotThrow(() =>
    service.validateFeedHttpResponse({
      status: 200,
      data: '<?xml version="1.0"?><rss><channel><title>Feed</title></channel></rss>',
      headers: { 'content-type': 'application/rss+xml; charset=utf-8' }
    })
  );
});

test('extractAuthorName normalizes structured atom author objects', () => {
  const service = new NewsService();

  const author = service.extractAuthorName(
    {
      author: {
        name: ['Lucia Loher'],
        title: ['Product Manager']
      }
    },
    'Google AI Blog'
  );

  assert.equal(author, 'Lucia Loher');
});
