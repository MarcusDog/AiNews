const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ainews-db-'));
process.env.AINEWS_DB_PATH = path.join(tmpDir, 'test.db');

process.on('exit', () => {
  fs.rmSync(tmpDir, { recursive: true, force: true });
});

const DatabaseService = require('../services/DatabaseService');

test('DatabaseService initializes and persists news entries', async () => {
  await DatabaseService.initialize();

  const saved = await DatabaseService.saveNews([
    {
      id: 'news-1',
      title: 'Test article',
      description: 'desc',
      url: 'https://example.com/a',
      publishedAt: new Date('2026-04-03T00:00:00Z').toISOString(),
      category: 'AI新闻',
      source: 'Test Source',
      imageUrl: null,
      author: 'Tester'
    }
  ]);

  assert.equal(saved, 1);
  assert.equal(await DatabaseService.getNewsCount(), 1);
  assert.deepEqual(await DatabaseService.all('SELECT title, source FROM news'), [
    { title: 'Test article', source: 'Test Source' }
  ]);

  await DatabaseService.close();
});

test('DatabaseService updateRssSourceStatus accepts boolean success flags', async () => {
  await DatabaseService.initialize();

  await DatabaseService.updateRssSourceStatus(
    'Test Feed',
    'https://example.com/feed.xml',
    true,
    null
  );

  const row = await DatabaseService.get(
    'SELECT name, fail_count, is_active FROM rss_sources WHERE name = ?',
    ['Test Feed']
  );

  assert.deepEqual(row, {
    name: 'Test Feed',
    fail_count: 0,
    is_active: 1
  });

  await DatabaseService.close();
});

test('DatabaseService resetFailedSources works after reconnecting', async () => {
  await DatabaseService.initialize();
  await DatabaseService.updateRssSourceStatus(
    'Recoverable Feed',
    'https://example.com/feed.xml',
    false,
    'boom'
  );
  await DatabaseService.close();

  await DatabaseService.resetFailedSources();

  const row = await DatabaseService.get(
    'SELECT name, fail_count, is_active, error_message FROM rss_sources WHERE name = ?',
    ['Recoverable Feed']
  );

  assert.deepEqual(row, {
    name: 'Recoverable Feed',
    fail_count: 0,
    is_active: 1,
    error_message: null
  });

  await DatabaseService.close();
});
